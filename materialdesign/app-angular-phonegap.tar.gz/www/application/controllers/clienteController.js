(function(){
    angular.module('app')
        .controller('clienteController', clienteController);

    function clienteController(){
        
    }
})();