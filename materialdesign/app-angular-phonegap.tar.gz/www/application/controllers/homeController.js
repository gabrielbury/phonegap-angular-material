// nos controllers programamos as telas.
// é aqui que pegaremos CLICK de botoes, EVENTOS de telas
// toda a inteligencia, programacao js fica no controllers
(function(){
    angular.module('app')
        .controller('homeController', homeController);

    function homeController(){
        
    }
})();